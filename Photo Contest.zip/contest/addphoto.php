<?php
session_start();
include 'db.php';
include 'header.php';

	if(count($_FILES)>0)
	{
		extract($_POST);
		$target_dir = "photos/";
		$image = time().'_'.basename($_FILES["image"]["name"]);
		if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir . $image))
			$done = $db->query("INSERT INTO photos (name,image,user,description) VALUES ('$name','$image','$user','$description')");
		if($done)
			echo '<script>alert("Photo added");window.location.href="index.php";</script>';
		else
			echo '<script>alert("Photo not uploaded");</script>';
	}
?>
<div class="row">
	<div class="col-12">
			<form action="" method="POST" enctype="multipart/form-data">
				<div class="form-group">
			      <label for="usr">Your Name:</label>
			      <input type="text" class="form-control" name="user" value="" required>
			   </div>
				<div class="form-group">
			      <label for="usr">Photo Name:</label>
			      <input type="text" class="form-control" name="name" value="" required>
			   </div>
			   <div class="form-group">
			      <label for="email">Photo:</label>
			      <input type="file" class="form-control" name="image"required>
				</div>
				<div class="form-group">
			      <label>Description:</label>
			      <textarea class="form-control" name="description"></textarea>
				</div>
			   <button type="submit" class="btn btn-success" id="addButton">Add photo</button>
			</form>
		</div>

</div>
<?php

include 'footer.php';
?>
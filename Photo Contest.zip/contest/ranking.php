<?php
session_start();
include 'db.php';
include 'header.php';

$results = $db->query("SELECT * FROM photos Order By votes desc");
?>
<div class="row" style="padding: none;margin: none">
	<table class="table table-bordered">
    <thead>
      <tr>
      	<th>Ranking</th>
        <th>Name</th>
        <th>Votes</th>
        <th>Photo Name</th>
        <th>Photo</th>
      </tr>
    </thead>
    <tbody>

<?php $i=1; while($data = $results->fetch_assoc()): ?>
	<tr>
		<td><?=$i?></td>
		<td><?=$data["user"]?></td>
        <td><?=$data["votes"]?></td>
        <td><?=$data["name"]?></td>
        <td><img src="photos/<?=$data["image"]?>" alt="<?=$data["image"]?>" width="100"></td>
    </tr>
<?php $i++; endwhile; ?>
	</tbody>
  </table>
</div>
<?php

include 'footer.php';
?>
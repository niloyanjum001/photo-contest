<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<title>Photo Contest</title>

<link href="css/bootstrap.css" rel="stylesheet">

</head>
<body>
	<div class="container">

		<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
			<a class="navbar-brand" href="index.php">Photo Contest</a>
		  <!-- Links -->
		  <ul class="navbar-nav">
		    <li class="nav-item">
		      <a class="nav-link" href="addphoto.php">Add Photo</a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="ranking.php">Ranking</a>
		    </li>
		  </ul>

		</nav>

<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$db = mysqli_connect($servername, $username, $password,'contest');
// mysqli_connect($servername, $username, $password,$db);

// Check connection
// if ($db->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// } 
if (!$db) {
   die("Connection failed: " . mysqli_connect_error());
}
?>
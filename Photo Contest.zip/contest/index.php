<?php
session_start();
include 'db.php';
include 'header.php';

$results = $db->query("SELECT * FROM photos");
?>
<div class="row">
<?php while($data = $results->fetch_assoc()): ?>
	<div class="col-lg-4 col-md-6 col-sm-12">
		<div class="card" style="width:400px">
		  <img class="card-img-top" src="photos/<?=$data["image"]?>" alt="<?=$data["image"]?>" height="250px" width="100%">
		  <div class="card-body">
		    <h4 class="card-title"><?=$data["name"]?></h4>
		    <p class="card-text"><?=$data["description"]?></p>
		    <a href="vote.php?id=<?=$data["id"]?>" class="btn btn-primary">Vote</a> <button class="btn"><?=$data["votes"]?> Votes</button>
		  </div>
		  <div class="card-footer">
		  	By <?=$data["user"]?>
		  </div>
		</div>
	</div>
<?php endwhile; ?>
</div>
<?php

include 'footer.php';
?>
<?php
session_start();
include 'db.php';

if(!isset($_GET["id"]))
{
	header("Location:index.php");
	exit;
}

$id = $_GET["id"];

if(isset($_SESSION["votes"][$id]))
{
	echo '<script>alert("You have already voted this photo");window.location.href="index.php";</script>';
	exit;
}

if($db->query("UPDATE photos SET votes=votes+1 WHERE id=$id"))
{
	echo '<script>alert("You have successfully voted this photo");window.location.href="index.php";</script>';
	$_SESSION["votes"][$id] = true;
	exit;
}
else
{
	echo '<script>alert("Problem here");window.location.href="index.php";</script>';
	exit;
}


?>